package jesuitas.dam.exam1ev;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String nameEditText;
    private String adressEditText;
    private String phoneEditText;
    private TextView nameTextView;
    private TextView addressTextView;
    private TextView phoneTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();
        nameEditText = intent.getStringExtra(InfoActivity.NAME);
        adressEditText = intent.getStringExtra(InfoActivity.ADRESS);
        phoneEditText = intent.getStringExtra(InfoActivity.PHONE);
        nameTextView = findViewById(R.id.nameData);
        nameTextView.setText(nameEditText);
        addressTextView = findViewById(R.id.adressData);
        addressTextView.setText(adressEditText);
        phoneTextView = findViewById(R.id.phoneData);
        phoneTextView.setText(phoneEditText);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void info(MenuItem item) {
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);
    }

    public void mail(MenuItem item) {
        String address = addressTextView.getText().toString();
        String[] addresses = {address};
        String subject = "Aviso";
        if (address.isEmpty()) {
            Toast.makeText(this, "No se ha encontrado e-mail", Toast.LENGTH_SHORT).show();
        }
        else {


            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SENDTO);
            sendIntent.setData(Uri.parse("mailto:"));
            sendIntent.putExtra(Intent.EXTRA_EMAIL, addresses);
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, subject);

            if (sendIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(sendIntent);
            } 
        }
    }

    public void call(MenuItem item) {
        String phone = phoneTextView.getText().toString();
        if (phone.isEmpty()) {
            Toast.makeText(this, "No se ha encontrado teléfono.", Toast.LENGTH_SHORT).show();
        } else {
            Intent callIntent = new Intent(Intent.ACTION_DIAL);
            callIntent.setData(Uri.parse("tel:" + phone));
            if (callIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(callIntent);
            }
        }
    }
}

