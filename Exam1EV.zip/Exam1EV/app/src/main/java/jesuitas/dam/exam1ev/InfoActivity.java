package jesuitas.dam.exam1ev;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class InfoActivity extends AppCompatActivity {

    public static final String NAME = "name";
    public static final String ADRESS = "adress";
    public static final String PHONE = "phone";
    private EditText name;
    private EditText address;
    private EditText phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        name = findViewById(R.id.editName);
        address = findViewById(R.id.editAdress);
        phone = findViewById(R.id.editPhone);



    }

    public void submit(View view) {
        String nombre = name.getText().toString();
        String direccion = address.getText().toString();
        String telefono = phone.getText().toString();
        if (nombre.isEmpty()||direccion.isEmpty()||telefono.isEmpty()  ){
            Toast.makeText(this, "Fill all data", Toast.LENGTH_LONG).show();
        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.sure)
                    .setTitle(R.string.confirm)
                    .setPositiveButton(R.string.Yes, (dialog, id) -> changeData())
                    .setNegativeButton("No", (dialog, id) -> corrigeData())
                    .create()
                    .show();
       }
    }

    private void corrigeData() {
        Toast.makeText(this, "Check data", Toast.LENGTH_LONG).show();
    }
    private void changeData() {
        String nombre = name.getText().toString();
        String direccion = address.getText().toString();
        String telefono = phone.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(NAME, nombre);
        intent.putExtra(ADRESS, direccion);
        intent.putExtra(PHONE, telefono);
        startActivity(intent);
    }
}